"use client";

import { useEditorStore } from "@/store/editorStore";
import { useUiStore } from "@/store/uiStore";
import { ExportDialog } from "./ExportDialog";
import { BatchUploadDialog } from "./BatchUploadDialog";
import { TemplatePanel } from "./TemplatePanel";
import { Toast } from "./Toast";
import { SearchPanel } from "./SearchPanel";
import { PageSetupDialog } from "./PageSetupDialog";
import { ShortcutsPanel } from "./ShortcutsPanel";
import { TableOfContentsPanel } from "./TableOfContentsPanel";
import { DialogSystem } from "./DialogSystem";
import { MobileBlock } from "@/components/MobileBlock";

interface DialogManagerProps {
  editor: import("@tiptap/react").Editor | null;
}

export function DialogManager({ editor }: DialogManagerProps) {
  const searchOpen = useUiStore((s) => s.searchOpen);
  const closeSearch = useUiStore((s) => s.closeSearch);
  const pageSetupOpen = useUiStore((s) => s.pageSetupOpen);
  const closePageSetup = useUiStore((s) => s.closePageSetup);
  const shortcutsOpen = useUiStore((s) => s.shortcutsOpen);
  const closeShortcuts = useUiStore((s) => s.closeShortcuts);
  const tocOpen = useUiStore((s) => s.tocOpen);
  const closeToc = useUiStore((s) => s.closeToc);

  return (
    <>
      <ExportDialog />
      <DialogSystem />
      <BatchUploadDialog />
      <TemplatePanel />
      <Toast />
      <SearchPanel editor={editor} open={searchOpen} onClose={closeSearch} />
      <PageSetupDialog open={pageSetupOpen} onClose={closePageSetup} />
      <ShortcutsPanel open={shortcutsOpen} onClose={closeShortcuts} />
      <TableOfContentsPanel editor={editor} open={tocOpen} onClose={closeToc} />
      <MobileBlock />
    </>
  );
}
