"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils";
import { ProcessedContent } from "./ProcessedContent";
import type { PageSetup } from "@/store/editorStore";

interface MultiPagePreviewProps {
  html: string;
  pageSetup: PageSetup;
  className?: string;
}

function splitByPageBreaks(rawHtml: string): string[] {
  if (!rawHtml) return [""];

  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(rawHtml, "text/html");
    const body = doc.body;

    const pages: string[] = [];
    let currentParts: string[] = [];

    Array.from(body.childNodes).forEach((node) => {
      if (
        node.nodeType === Node.ELEMENT_NODE &&
        (node as Element).classList?.contains("page-break")
      ) {
        if (currentParts.length > 0) {
          pages.push(currentParts.join(""));
          currentParts = [];
        }
      } else {
        currentParts.push(nodeToHtml(node));
      }
    });

    if (currentParts.length > 0 || pages.length === 0) {
      pages.push(currentParts.join(""));
    }

    return pages.length > 0 ? pages : [""];
  } catch {
    // Fallback: simple string split on known page-break marker
    const marker = '<div class="page-break"></div>';
    const parts = rawHtml.split(marker);
    return parts.filter((segment, _index, arr) => segment.trim().length > 0 || arr.length === 1);
  }
}

function nodeToHtml(node: Node): string {
  if (node.nodeType === Node.ELEMENT_NODE) {
    return (node as Element).outerHTML;
  }
  if (node.nodeType === Node.TEXT_NODE) {
    return node.textContent ?? "";
  }
  return "";
}

export function MultiPagePreview({ html, pageSetup, className }: MultiPagePreviewProps) {
  const pages = useMemo(() => {
    return splitByPageBreaks(html);
  }, [html]);

  return (
    <div className={cn("flex flex-col items-center gap-8 py-8", className)}>
      {pages.map((pageHtml, index) => (
        <div key={index} className="relative">
          <ProcessedContent
            html={pageHtml}
            pageSetup={pageSetup}
            className="overflow-hidden"
            exactHeight
          />
          <div className="pointer-events-none absolute bottom-2 left-0 right-0 text-center text-[11px] text-[color:var(--color-muted-foreground)]">
            {index + 1}
          </div>
        </div>
      ))}
    </div>
  );
}
